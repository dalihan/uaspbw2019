console.log("****************************************************************");
console.log("		Selamat Datang di Website MNC Bank	");
console.log("****************************************************************");
console.log("	Ujian Akhir Semester Pemrograman Berbasis Web 	 	");
console.log("****************************************************************");
console.log(15+5);
console.log(15-5);
console.log(15*5);
function perkalian (x,y)
{
  var hasil = x * y;
  return hasil;
}
console.log(perkalian(5,3));
function myFunction()
{
  myOtherFunction();
}
function myOtherFunction()
{
  console.trace();
}

console.time("Running Time");
console.timeEnd("Running Time");