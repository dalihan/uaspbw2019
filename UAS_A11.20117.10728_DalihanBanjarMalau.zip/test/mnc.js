(function($) {
	$.fn.forceNum = function() {
		return this.each(function() {
			$(this).keyup(function() {
				if(!/^[0-9]+$/.test($(this).val())) {
					$(this).val($(this).val().replace(/[^0-9]/g, ''));
				}
			}).keydown(function() {
				if(!/^[0-9]+$/.test($(this).val())) {
					$(this).val($(this).val().replace(/[^0-9]/g, ''));
				}
			}).blur(function() {
				if(!/^[0-9]+$/.test($(this).val())) {
					$(this).val($(this).val().replace(/[^0-9]/g, ''));
				}
			});
		});
	};
})(jQuery);

function addCommas(nStr) {
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + '.' + '$2');
	}
	return x1 + x2;
}

function close_offcanvas() {
	$('body').removeClass('offcanvas-menu-open');
}

function change_mymenu(uri) {
	window.location = site_url + uri;
}

$(function() {
	$("a.sharing-sos-med").click(function(){var b=$(this),c=$(window),d=b.attr("href"),a=c.width();windowHeight=c.height();alignLeft=(a-500)/2;alignTop=(windowHeight-300)/2;window.open(d,"social-network-window","height=300,width=500,scrollbars=1,left="+alignLeft+",top="+alignTop);return false});
	
	$('select.custom-select').each(function(){
		el = $(this);
		if (el.find('option:selected') != 0) {
			text = el.find('option:selected').text();
		} else {
			text = el.siblings('.replacement').attr('data-text');
		}
		el.siblings('.replacement').html(text);
	});
	
	$('.forceNum').forceNum();
	
	$(".language").click(function(){
		$(".toggle.box-language").stop(true, true).slideToggle();
	});
	
	$(".account").click(function(){
		$(".toggle.box-account").stop(true, true).slideToggle();
	});
	
	$('.search-toggle').click(function() {
		$('.tsearch').stop(true, true).fadeIn().find('input[type="text"]').focus();
	});
	
	$('html').click(function(e) {
		if ( ! $(e.target).is('.tsearch') && ! $(e.target).is('.search-toggle') && ! $(e.target).is('.icon-search') && ! $(e.target).is('.tsearch input')) {
			$('.tsearch').stop(true, true).fadeOut();
		}
		if (!$(e.target).is('.list-language') && !$(e.target).parents().is('.list-language')) {
			$(".toggle.box-language").stop(true, true).slideUp();
		}
		if (!$(e.target).is('.list-account') && !$(e.target).parents().is('.list-account')) {
			$(".toggle.box-account").stop(true, true).slideUp();
		}
		if (!$(e.target).is('.box-key') && !$(e.target).is('.box-account2') && !$(e.target).parents().is('.box-account2')) {
			$('.box-account2').stop(true, true).slideUp();
		}
		$(".full-img").fadeOut();
	});
	
	$('.menu-toggle').click(function() {
		if ($('body').hasClass('offcanvas-menu-open')) {
			close_offcanvas();
		} else {
			$('body').addClass('offcanvas-menu-open');
		}
	});
	
	$('.txt-index span').click(function() {
		$('html, body').animate({scrollTop: $(document).height()}, 500);
		if ($(this).hasClass('active')) {
			$(this).removeClass('active');
			$('.footer-toggle').stop(true, true).slideUp();
		} else {
			$(this).addClass('active');
			$('.footer-toggle').stop(true, true).slideDown();
		}
	});

	$('.footer-toggle .sub-toggle a').click(function(e) {
		e.preventDefault();
		a = $(this).attr('data-tab');
		$('.footer-toggle .sub-toggle a').removeClass('active');
		$(this).addClass('active');
		$('.footer-toggle .data-tab').removeClass('active');
		$('.footer-toggle .data-tab.data-tab-'+a).addClass('active');
		$('html, body').animate({scrollTop: $(document).height()}, 500);
	});
	
	$('#home-slider.owl-carousel').owlCarousel({
		slideSpeed : 300,
		paginationSpeed : 400,
		singleItem:true,
		autoPlay: true,
		pagination : true,
		paginationNumbers: false
	});

	$('.menu-parent .dropdown > a').click(function(e) {
		e.preventDefault();
		if ($(this).hasClass('active')) {
			$(this).removeClass('active');
			$(this).closest('li').find('.menu-child').hide(300);
		} else {
			$(this).addClass('active');
			$(this).closest('li').find('.menu-child').show(300);
		}
	});
	$('.box-key').click(function() {
		$('.box-account2').stop(true, true).slideToggle();
	});
	
	h = $('.left-simul').height();
	$('.bdr-simulation').css({'height':(h)});
	
	$('#index-slider.owl-carousel').owlCarousel({
		slideSpeed : 300,
		paginationSpeed : 400,
		singleItem:true,
		autoPlay: true,
		pagination : true,
		paginationNumbers: false
	});
	
	
	b = $('.content-home').width();
	
	$('.slider-next').click(function() {
		$('.index-content').css({'left':'-'+($('.index-content').width()-$(window).width()+40)+'px'});
		$('.slider-next').hide();
		$('.slider-prev').show();
	});
	$('.slider-prev').click(function() {
		$('.index-content').css({'left':'0'});
		$('.slider-prev').hide();
		$('.slider-next').show();
	});
	
	$(window).resize(function() {
		if ($(window).width() >= 992 && $('.slider-prev').is(':visible')) {
			$('.index-content').css({'left':'-'+($('.index-content').width()-$(window).width()+40)+'px'});
		} else {
			$('.index-content').css({'left':0});
		}
	});
	
	$(document).keydown(function(e) {
		if (e.keyCode == 27) {
			$('.full-close').click();
		}
	});
	
	$('.full-close').click(function() {
		$(".full-img").fadeOut();
	});
	
	$('.img-answer').click(function() {
		$('.box-answer').stop(true, true).slideToggle();
	});
	
	$('.menu-parent .dropdown2 > a').click(function(e) {
		e.preventDefault();
		if ($(this).hasClass('active')) {
			$(this).removeClass('active');
			$(this).closest('li').find('.menu-child2').hide(300);
		} else {
			$(this).addClass('active');
			$(this).closest('li').find('.menu-child2').show(300);
		}
	});
});

function custom_select(e) {
	el = $(e);
	if (el.find('option:selected').text() != '') {
		text = el.find('option:selected').text();
	} else {
		text = el.siblings('.replacement').attr('data-text');
	}
	el.siblings('.replacement').html(text);
}