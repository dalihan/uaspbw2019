var konfirmasi = confirm("Selamat datang di Website Resmi MNC Bank. Apakah anda ingin melanjutkan?")
if(konfirmasi==true)
{
  document.location.href="##";
}
else
{
  document.location.href="";
}